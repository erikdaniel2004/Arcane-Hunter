⚠️ Instrucciones para abrir Arcane Hunter en macOS ⚠️

macOS puede bloquear esta aplicación porque no ha sido firmada ni notarizada por Apple.
Esto es normal si el juego fue creado fuera del App Store.

Para poder jugar:

1. Descomprime el archivo ZIP.
2. Ve a la carpeta donde esté "ArcaneHunter.app".
3. Haz clic derecho sobre la aplicación y elige **"Abrir"**.
4. En la ventana que aparece, haz clic en **"Abrir de todos modos"**.
   (Esto solo es necesario la primera vez).

💡 También puedes permitir la ejecución manualmente desde:
   **Preferencias del Sistema > Seguridad y Privacidad > General**

No te preocupes, este archivo no contiene ningún tipo de virus ni software malicioso. Ha sido exportado directamente desde Godot Engine por el desarrollador.

¡Gracias por jugar Arcane Hunter!
